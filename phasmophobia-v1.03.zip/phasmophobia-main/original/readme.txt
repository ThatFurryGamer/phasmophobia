This file contains the original Assembly.dll file in case things go wrong
